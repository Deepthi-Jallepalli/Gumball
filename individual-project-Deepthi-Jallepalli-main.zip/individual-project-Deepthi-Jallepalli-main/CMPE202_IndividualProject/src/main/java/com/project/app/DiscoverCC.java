import java.util.Date;

public class DiscoverCC extends CreditCard {

	public DiscoverCC(String cardNumber, Date expDate, String name, String cardType, boolean isValid) {
		super(cardNumber, expDate, name, cardType, isValid);
	}

}

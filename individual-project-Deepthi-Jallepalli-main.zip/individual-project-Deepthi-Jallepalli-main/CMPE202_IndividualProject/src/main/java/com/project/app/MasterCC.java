import java.util.Date;

public class MasterCC extends CreditCard {

	public MasterCC(String cardNumber, Date expDate, String name, String cardType, boolean isValid) {
		super(cardNumber, expDate, name, cardType, isValid);
	}

}
